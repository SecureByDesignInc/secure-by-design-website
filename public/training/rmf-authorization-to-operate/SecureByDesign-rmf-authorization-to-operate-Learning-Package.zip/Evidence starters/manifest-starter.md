# Authorization package manifest

Secure By Design — blank training starter

Identify the exact records submitted for the AO’s decision, what each one satisfies (JSIG Task 5-2, NIST Task R-1), and whether their scope and versions agree.

Owner: System owner and package coordinator

| Package component | Basis | Identifier / version | Owner | Review check |
| --- | --- | --- | --- | --- |
| [Required component] | [JSIG 5-2 / NIST R-1 / AO direction] | [Document ID / version / date] | [Responsible role] | [Required review / status] |

---

The JSIG sets a minimum and the AO can direct more; the applicable authority sets the format and submission path. This manifest does not establish submission or approval.
