# Security impact analysis

Secure By Design — blank training starter

Decide what a proposed or actual change does to the security posture before it goes ahead: which controls and records it touches, what must be reassessed, and who must be told (NIST M-1, JSIG 6-1).

Owner: System owner with the ISSM and ISSO

## Change

Change ID, what changes and why, requester, proposed date, affected components and information flows.

## Security impact

Affected controls, implementations, and evidence, and the effect on each: better, worse, or unknown.

## Determination

Significant or not, and why; what must be reassessed; whether the boundary or categorization changes.

## Notifications and approvals

Who is told or must approve before the change: SCA, ISSM, change board, AO or designee.

## Records to update

Which package records change, who updates them, and which versions are kept.

## Outcome

Approved, deferred, or rejected; the reassessment result; date closed; the status report that carried it.

---

The authority’s change process decides who approves a change and when the AO must be engaged. The example is a fictional change to the practice system.
