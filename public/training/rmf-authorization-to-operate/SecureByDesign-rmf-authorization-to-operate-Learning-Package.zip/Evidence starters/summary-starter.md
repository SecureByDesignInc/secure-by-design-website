# Executive risk summary

Secure By Design — blank training starter

Give the AO the system, the assessed posture, the significant risk, and the decision requested on one page: the package’s executive summary and the basis of the briefing.

Owner: System owner with risk stakeholders

## System and mission

What the system enables, its boundary and categorization, the authority, and the package version under review.

## Assessment result

Significant supported results, limitations, and the assessor’s recommendation, quoted from the SAR.

## Risk to the mission

Consequences, likelihood, uncertainty, existing safeguards, and the significant open findings, consistent with the RAR.

## Proposed response

For each significant risk: mitigate (POA&M actions, conditions), accept, or avoid, with owners and alternatives.

## Decision requested

The decision requested (ATO, IATT, or DATO), the proposed duration, and who is authorized to decide.

---

The summary informs the decision; it doesn’t make it. Keep recommendations separate from the AO’s recorded decision and its conditions.
