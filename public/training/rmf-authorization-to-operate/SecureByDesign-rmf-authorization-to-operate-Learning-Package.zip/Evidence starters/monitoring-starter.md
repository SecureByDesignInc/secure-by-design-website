# Continuous monitoring strategy

Secure By Design — blank training starter

Define what is monitored, how often, by whom, and what triggers action, so the authorization basis stays current. Written in Select (S-5; JSIG Task 2-3) and run in module 12.

Owner: System owner (ISO) with control owners; approved by the Authorizing Official (AO)

| Activity | Owner | Frequency / trigger | Evidence and escalation |
| --- | --- | --- | --- |
| [Monitoring activity and the NIST and JSIG task it serves] | [Role] | [Frequency or trigger approved in the strategy] | [Record produced / threshold / action] |

---

Frequencies and thresholds are dependent on your environment and set by the applicable direction and system risk; this example doesn’t prescribe universal intervals. Module 12 runs the strategy and records each security impact analysis.
