# Authorization decision document

Secure By Design — blank training starter

Practice recording what an AO’s decision contains: the decision, its terms and conditions, its duration, and what monitoring must report.

Owner: Authorizing official (played by the reviewer)

## System and scope

System name, boundary, and the package version the AO reviewed.

## Decision

ATO, IATT, or DATO (JSIG); NIST also names authorization to use, common control authorization, and denial. Who decided, and when.

## Terms and conditions

What must be done, maintained, or limited for the decision to stand, and who is responsible.

## Duration

Time-driven (an end date) or ongoing authorization backed by robust continuous monitoring, and the events that trigger an earlier review.

## Monitoring and reporting

What the system owner reports, when (event-driven, time-driven, or both), and to whom.

## Authority and signature

Who signed, under which authority, and what the record is not.

---

Exercise material only. A real authorization decision document is issued and signed by the appointed AO under the governing authority; nothing in this course grants an ATO, IATT, or DATO.
