# Security Assessment Plan

Secure By Design — blank training starter

Define who assesses, what they receive, and what will be assessed and how, so the results are defensible.

Owner: Control assessor and system owner

## Assessor and independence

Assessor or team, who selected them, and the independence they provide (NIST A-1).

## Evidence received

Documents and records handed over, with versions, dates, and known exceptions.

## Scope and objectives

System and version, selected controls and objectives, exclusions, assumptions.

## Methods, objects, and expected results

Examine, interview, or test for each objective; objects; coverage and sampling rationale; expected results.

## Responsibilities, schedule, and approval

Assessor, system contacts, dates, and the plan’s review and approval (A-2; JSIG 4-1; CA-2).

## Limitations and safety

Collection limits, access needs, constraints, authorized test conditions.

---

Assessment plan is written in full here to avoid confusing its acronym with Special Access Program. In the JSIG, the Security Assessment Plan is made up of the SSP, the SCTM, and the Security Control Assessment Procedures; this excerpt shows the procedures.
