# Security Controls Traceability Matrix

Secure By Design — blank training starter

Record each selected control’s source, tailoring, parameters, allocation, and inheritance, then trace it to implementation, evidence, and results. Started in Select; module 05 adds the as-implemented statements.

Owner: System owner (ISO) and security team, with implementation owners

| Control | Selection and tailoring | Parameters | Allocation and inheritance | Implementation and trace |
| --- | --- | --- | --- | --- |
| [ID / title / adopted revision] | [Baseline or overlay source; tailoring decision, rationale, approval] | [Organization-defined values and their source] | [System-specific, common, or hybrid; provider and what it supplies; components; owner] | [Planned (module 04), then as implemented (module 05); evidence, result, and finding IDs] |

---

Mappings are instructional. Expand rows to the exact selected control parts and assessment objectives; a single record doesn’t prove an entire control. In the JSIG, the SCTM is part of the System Security Plan.
