# System scope record

Secure By Design — blank training starter

Agree on the roles, governing direction, mission, boundary, information, early risks, and requirements before the package grows. Module 01 starts it, module 02 completes the Prepare fields, and module 03 adds the categorization basis.

Owner: System owner (ISO) with the security team

## Roles and governing direction

Who holds each role, in NIST and JSIG terms; the governing documents, their editions, and the adopted control release.

## Mission and stakeholders

Missions and business processes the system supports (P-8); everyone with an interest in it (P-9).

## Assets and boundary

Assets to protect (P-10); the authorization boundary the AO determines (P-11), with management paths, shared services, and external dependencies.

## Information types and life cycle

Information the system processes, stores, and transmits (P-12), and each type’s path from creation to disposal (P-13), including boundary transfers.

## Early risk picture

The first system risk assessment (P-14): threats, weaknesses or conditions, likely consequences, and assumptions. Module 04 carries it into the draft Risk Assessment Report (RAR).

## Requirements and allocation

Security and privacy requirements (P-15), the system’s place in the architecture (P-16), and where each requirement lands (P-17), including candidate common controls.

## Categorization basis

Method and authority, the information types considered, and where the result is recorded and approved. Completed in module 03.

---

The scope record is an exercise starter. The relevant authority determines the formal boundary, categorization, and approval requirements.
