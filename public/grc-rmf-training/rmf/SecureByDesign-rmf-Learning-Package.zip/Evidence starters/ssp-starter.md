# System Security Plan

Secure By Design — blank training starter

Describe the system and its categorization, record the plan’s approval, and explain how each selected control is implemented.

Owner: System owner with the security team and engineers

## System description

Name, identifier, mission, boundary, components, environment, and references (NIST C-1; JSIG 1-2).

## Security categorization

Information types; confidentiality, integrity, and availability impacts with rationale; method; reviewer; approval (C-2, C-3; JSIG 1-1).

## Plan review and approval

Version reviewed, reviewer and role, date, decision, and any conditions (S-6; JSIG 2-4).

## As-implemented control statements

Control ID and adopted revision, approved parameters (from the SCTM), and who does what, where, when, and with which records (I-2; JSIG 3-2).

## Evidence and responsibilities

Evidence identifiers, owners, provider dependencies, and review status.

## Limitations and planned work

Separate what operates from planned work and known gaps.

## Recorded risk decisions

Risk responses, rationale, mitigation, decision owner, and review trigger.

---

The example is an excerpt, not a full SSP or a finding of compliance. In the JSIG, the SSP also includes the SCTM, the continuous monitoring strategy, and a Risk Assessment Report; this course keeps them as separate practice artifacts.
