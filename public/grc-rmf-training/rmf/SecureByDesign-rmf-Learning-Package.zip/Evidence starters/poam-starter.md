# Plan of Action and Milestones

Secure By Design — blank training starter

Turn an open finding into a risk-ranked, resourced, dated plan that the AO can review and use to monitor progress.

Owner: System owner and remediation owner

## Finding and affected scope

POA&M ID, finding ID, controls and objectives, affected assets.

## Risk and priority

Threat, exposure, mission consequence, current safeguards, uncertainty, and the resulting rank.

## Owner, resources, and milestones

Accountable owner, actions, resources, target dates, dependencies.

## Closure criteria

What must be verified, by whom, and with which record.

## Status and decision

Open or closed, milestone updates, the AO’s review, any risk decision reference.

---

Milestone tracking and risk acceptance are separate responsibilities. Follow the authority’s required POA&M format. FND-002 has no entry because it was fixed and reassessed during the assessment.
