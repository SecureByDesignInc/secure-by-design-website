# System registration

Secure By Design — blank training starter

Register the system with the office the organization or program designates, so it is known, tracked, and accountable before the package grows. NIST registers in Prepare (P-18); the JSIG in Categorize (Task 1-3).

Owner: System owner (ISO)

## System identity

Name, registration number, owner, and points of contact.

## Registered with

The office the organization designates (NIST P-18) or, for a Special Access Program (SAP) system, the appropriate SAP Service/Agency Authorizing Official (AO) or designee (JSIG Task 1-3).

## Purpose and characteristics

The mission in a sentence or two, location, connections, and operating status.

## Boundary summary

What the authorization covers, with a reference to the documented boundary.

## Categorization and plan status

The approved security categorization, the System Security Plan reference, and the authorization status.

## Update triggers

Changes that require an update to the registration.

---

A fictional exercise record. The registering office, the required content, and the format follow the organization’s or program’s policy.
