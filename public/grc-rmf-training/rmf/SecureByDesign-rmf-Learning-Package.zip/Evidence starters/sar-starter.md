# Security Assessment Report

Secure By Design — blank training starter

Record what was assessed, what was observed, the findings and limitations, and the result of any reassessment.

Owner: Control assessor (the JSIG’s security control assessor)

## Assessment basis

Approved plan, scope and version, objectives, dates, assessor.

## Observed results

Actual observation and evidence for each objective; satisfied or other than satisfied.

## Findings

Finding ID, affected scope, requirement and objective, evidence, effect.

## Conclusions and limitations

Supported determinations, missing support, scope limits.

## Recommendations

Corrections the assessor recommends and, in the JSIG, the SCA’s recommended authorization decision.

## Initial remediation and reassessment

What was corrected, the reassessment result, and the original finding kept (A-5; JSIG 4-4).

---

The report is a fictional excerpt for practicing traceability and assessment writing. A reassessment adds results to the report; it never removes the original finding.
