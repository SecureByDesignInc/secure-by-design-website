# Risk Assessment Report

Secure By Design — blank training starter

Record the risks that remain with the selected controls, how likely and harmful each is, and what the assessment must confirm. Drafted in Select as a JSIG Step 2 output; module 08 updates it with assessment results.

Owner: System owner (ISO) with the ISSM and ISSO

| Risk | Planned safeguards | Likelihood and impact | Risk level | Response and next update |
| --- | --- | --- | --- | --- |
| [RSK-ID: threat event, the weakness or condition it exploits, and what it affects] | [Selected controls from the Security Controls Traceability Matrix (SCTM) that address it] | [Ratings and reasons, using the authority’s method and scale] | [Result, confidence, and assumptions] | [Planned response and owner; what the assessment must confirm (module 08)] |

---

Ratings are exercise values, not an assessment of any real system; use the method and scale your authority directs. In the JSIG’s authorization package, the System Security Plan includes a RAR (Task 5-2). Only the AO accepts risk.
